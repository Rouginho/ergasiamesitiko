// ============================================================
// data.js — Διαχείριση δεδομένων με localStorage
// ============================================================

const DB = {
  // Κλειδιά για localStorage
  KEYS: {
    properties: 're_properties',
    requests: 're_requests',
    contacts: 're_contacts',
  },

  // Αρχικά δεδομένα (demo)
  defaultProperties: [
    {
      id: 1,
      type: 'sale',
      category: 'apartment',
      title: 'Μοντέρνο διαμέρισμα στο κέντρο',
      price: 145000,
      area: 78,
      rooms: 2,
      bathrooms: 1,
      floor: 3,
      location: 'Αθήνα',
      neighborhood: 'Κολωνάκι',
      address: 'Σκουφά 14',
      year: 2018,
      description: 'Πωλείται φωτεινό διαμέρισμα 78τμ στην καρδιά του Κολωνακίου. Το ακίνητο βρίσκεται σε τρίτο όροφο πολυκατοικίας και διαθέτει υψηλές οροφές, σαλόνι-κουζίνα ανοιχτού σχεδίου, δύο υπνοδωμάτια και μπάνιο. Ανακαινισμένο πλήρως το 2020, με νέα κουζίνα, air condition και διπλά τζάμια.',
      amenities: ['Ανελκυστήρας', 'A/C', 'Ηλιακός', 'Φυσικό αέριο', 'Αποθήκη'],
      images: [
        'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&q=80',
        'https://images.unsplash.com/photo-1484154218962-a197022b5858?w=400&q=80',
        'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&q=80',
      ],
      agent: 'Γιώργος Παπαδόπουλος',
      phone: '210 123 4567',
      status: 'active',
      date: '2025-03-10',
      views: 142,
    },
    {
      id: 2,
      type: 'rent',
      category: 'apartment',
      title: 'Ευρύχωρο τριάρι με θέα',
      price: 750,
      area: 95,
      rooms: 3,
      bathrooms: 1,
      floor: 5,
      location: 'Θεσσαλονίκη',
      neighborhood: 'Άνω Πόλη',
      address: 'Ολύμπου 22',
      year: 2005,
      description: 'Ενοικιάζεται τριάρι 95τμ με εκπληκτική θέα στον Θερμαϊκό. Βρίσκεται σε πέμπτο όροφο πολυκατοικίας κοντά στο Λευκό Πύργο. Διαθέτει μεγάλο σαλόνι, 3 υπνοδωμάτια, κουζίνα και ένα μπάνιο. Ιδανικό για φοιτητές ή επαγγελματίες.',
      amenities: ['A/C', 'Φυσικό αέριο', 'Πάρκινγκ'],
      images: [
        'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&q=80',
        'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=400&q=80',
      ],
      agent: 'Μαρία Αντωνίου',
      phone: '2310 456 789',
      status: 'active',
      date: '2025-04-01',
      views: 88,
    },
    {
      id: 3,
      type: 'sale',
      category: 'house',
      title: 'Μονοκατοικία με κήπο',
      price: 320000,
      area: 160,
      rooms: 4,
      bathrooms: 2,
      floor: 2,
      location: 'Αθήνα',
      neighborhood: 'Παλαιό Φάληρο',
      address: 'Αμφιτρίτης 7',
      year: 1995,
      description: 'Πωλείται διώροφη μονοκατοικία 160τμ με κήπο 200τμ στο Παλαιό Φάληρο. Ισόγειο: σαλόνι, τραπεζαρία, κουζίνα, W/C. Α΄ όροφος: 4 υπνοδωμάτια, 2 μπάνια. Αυτόνομη θέρμανση, τζάκι, πλήρως επιπλωμένη. Κατάλληλη για μεγάλες οικογένειες.',
      amenities: ['Κήπος', 'Τζάκι', 'Αποθήκη', 'Φυσικό αέριο', 'Πάρκινγκ', 'A/C'],
      images: [
        'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800&q=80',
        'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=400&q=80',
      ],
      agent: 'Νίκος Δημητρίου',
      phone: '210 987 6543',
      status: 'active',
      date: '2025-02-20',
      views: 215,
    },
    {
      id: 4,
      type: 'rent',
      category: 'studio',
      title: 'Studio κοντά στο ΑΠΘ',
      price: 320,
      area: 35,
      rooms: 1,
      bathrooms: 1,
      floor: 2,
      location: 'Θεσσαλονίκη',
      neighborhood: 'Πολίτεια',
      address: 'Εγνατίας 88',
      year: 2010,
      description: 'Ενοικιάζεται studio 35τμ σε 2ο όροφο, λίγα βήματα από το ΑΠΘ. Ιδανικό για φοιτητή/τρια. Πλήρως επιπλωμένο με κουζίνα, μπάνιο και air condition. Αυτόνομη θέρμανση. Χωρίς κοινόχρηστα.',
      amenities: ['A/C', 'Επιπλωμένο'],
      images: [
        'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&q=80',
      ],
      agent: 'Ελένη Νικολάου',
      phone: '2310 111 222',
      status: 'active',
      date: '2025-04-05',
      views: 56,
    },
    {
      id: 5,
      type: 'sale',
      category: 'land',
      title: 'Οικόπεδο εντός σχεδίου',
      price: 85000,
      area: 420,
      rooms: 0,
      bathrooms: 0,
      floor: 0,
      location: 'Πάτρα',
      neighborhood: 'Ρίο',
      address: 'Ελ. Βενιζέλου 55',
      year: null,
      description: 'Πωλείται οικόπεδο 420τμ εντός σχεδίου στο Ρίο Πατρών. Συντελεστής δόμησης 0.8, επιτρέπεται κατοικία έως 3 ορόφους. Πρόσωπο σε ασφαλτοστρωμένο δρόμο, άμεση πρόσβαση σε μέσα μεταφοράς και αγορά.',
      amenities: ['Εντός σχεδίου', 'Γωνιακό'],
      images: [
        'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800&q=80',
      ],
      agent: 'Κώστας Ιωάννου',
      phone: '2610 222 333',
      status: 'active',
      date: '2025-01-15',
      views: 34,
    },
    {
      id: 6,
      type: 'rent',
      category: 'apartment',
      title: 'Ανακαινισμένο διαμέρισμα',
      price: 550,
      area: 65,
      rooms: 2,
      bathrooms: 1,
      floor: 1,
      location: 'Αθήνα',
      neighborhood: 'Νέος Κόσμος',
      address: 'Καλλιρρόης 30',
      year: 2000,
      description: 'Ενοικιάζεται πλήρως ανακαινισμένο διαμέρισμα 65τμ. Σαλόνι-κουζίνα, 2 υπνοδωμάτια, μπάνιο. Νέα πάτωμα, πλακάκια, κουζίνα και μπάνιο. Αυτόνομη θέρμανση φυσικού αερίου, A/C. Ήσυχη γειτονιά, κοντά στο Μετρό.',
      amenities: ['A/C', 'Φυσικό αέριο', 'Ανελκυστήρας'],
      images: [
        'https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=800&q=80',
        'https://images.unsplash.com/photo-1484101403633-562f891dc89a?w=400&q=80',
      ],
      agent: 'Γιώργος Παπαδόπουλος',
      phone: '210 123 4567',
      status: 'active',
      date: '2025-03-28',
      views: 97,
    },
  ],

  // Εκκίνηση — φόρτωση δεδομένων
  init() {
    if (!localStorage.getItem(this.KEYS.properties)) {
      localStorage.setItem(this.KEYS.properties, JSON.stringify(this.defaultProperties));
    }
    if (!localStorage.getItem(this.KEYS.requests)) {
      localStorage.setItem(this.KEYS.requests, JSON.stringify([]));
    }
    if (!localStorage.getItem(this.KEYS.contacts)) {
      localStorage.setItem(this.KEYS.contacts, JSON.stringify([]));
    }
  },

  // Ανάκτηση ακινήτων
  getProperties(filters = {}) {
    let props = JSON.parse(localStorage.getItem(this.KEYS.properties)) || [];
    // Εμφάνιση μόνο εγκεκριμένων στους επισκέπτες
    if (!filters.adminMode) {
      props = props.filter(p => p.status === 'active');
    }
    if (filters.type && filters.type !== 'all') {
      props = props.filter(p => p.type === filters.type);
    }
    if (filters.category && filters.category !== 'all') {
      props = props.filter(p => p.category === filters.category);
    }
    if (filters.location && filters.location !== 'all') {
      props = props.filter(p => p.location === filters.location);
    }
    if (filters.minPrice) {
      props = props.filter(p => p.price >= Number(filters.minPrice));
    }
    if (filters.maxPrice) {
      props = props.filter(p => p.price <= Number(filters.maxPrice));
    }
    if (filters.minArea) {
      props = props.filter(p => p.area >= Number(filters.minArea));
    }
    if (filters.rooms && filters.rooms !== 'all') {
      props = props.filter(p => p.rooms >= Number(filters.rooms));
    }
    if (filters.sort === 'price_asc') props.sort((a, b) => a.price - b.price);
    if (filters.sort === 'price_desc') props.sort((a, b) => b.price - a.price);
    if (filters.sort === 'area_desc') props.sort((a, b) => b.area - a.area);
    if (filters.sort === 'date_desc') props.sort((a, b) => new Date(b.date) - new Date(a.date));
    return props;
  },

  getProperty(id) {
    const props = JSON.parse(localStorage.getItem(this.KEYS.properties)) || [];
    return props.find(p => p.id === Number(id)) || null;
  },

  // Αίτηση καταχώρησης (περιμένει έγκριση admin)
  addRequest(data) {
    const requests = JSON.parse(localStorage.getItem(this.KEYS.requests)) || [];
    const newReq = {
      id: Date.now(),
      ...data,
      status: 'pending',
      date: new Date().toISOString().slice(0, 10),
    };
    requests.push(newReq);
    localStorage.setItem(this.KEYS.requests, JSON.stringify(requests));
    return newReq;
  },

  getRequests() {
    return JSON.parse(localStorage.getItem(this.KEYS.requests)) || [];
  },

  // Admin: έγκριση αίτησης
  approveRequest(id) {
    const requests = JSON.parse(localStorage.getItem(this.KEYS.requests)) || [];
    const idx = requests.findIndex(r => r.id === id);
    if (idx === -1) return;
    const req = requests[idx];
    req.status = 'approved';
    requests[idx] = req;
    localStorage.setItem(this.KEYS.requests, JSON.stringify(requests));

    // Προσθήκη στα ακίνητα
    const props = JSON.parse(localStorage.getItem(this.KEYS.properties)) || [];
    const newProp = { ...req, id: Date.now(), status: 'active' };
    delete newProp.ownerEmail;
    props.push(newProp);
    localStorage.setItem(this.KEYS.properties, JSON.stringify(props));
  },

  // Admin: απόρριψη
  rejectRequest(id) {
    const requests = JSON.parse(localStorage.getItem(this.KEYS.requests)) || [];
    const idx = requests.findIndex(r => r.id === id);
    if (idx !== -1) {
      requests[idx].status = 'rejected';
      localStorage.setItem(this.KEYS.requests, JSON.stringify(requests));
    }
  },

  // Admin: διαγραφή ακινήτου
  deleteProperty(id) {
    let props = JSON.parse(localStorage.getItem(this.KEYS.properties)) || [];
    props = props.filter(p => p.id !== Number(id));
    localStorage.setItem(this.KEYS.properties, JSON.stringify(props));
  },

  // Αποθήκευση μηνύματος επικοινωνίας
  saveContact(data) {
    const contacts = JSON.parse(localStorage.getItem(this.KEYS.contacts)) || [];
    contacts.push({ id: Date.now(), ...data, date: new Date().toISOString().slice(0, 10), read: false });
    localStorage.setItem(this.KEYS.contacts, JSON.stringify(contacts));
  },

  getContacts() {
    return JSON.parse(localStorage.getItem(this.KEYS.contacts)) || [];
  },

  // Αύξηση views
  incrementViews(id) {
    const props = JSON.parse(localStorage.getItem(this.KEYS.properties)) || [];
    const idx = props.findIndex(p => p.id === Number(id));
    if (idx !== -1) {
      props[idx].views = (props[idx].views || 0) + 1;
      localStorage.setItem(this.KEYS.properties, JSON.stringify(props));
    }
  },

  // Βοηθητικές
  formatPrice(price, type) {
    const formatted = price.toLocaleString('el-GR');
    return type === 'rent' ? `${formatted} €/μήνα` : `${formatted} €`;
  },

  getCategoryLabel(cat) {
    const labels = { apartment: 'Διαμέρισμα', house: 'Μονοκατοικία', studio: 'Studio', land: 'Οικόπεδο', commercial: 'Επαγγελματικό' };
    return labels[cat] || cat;
  },

  getLocationLabel(loc) {
    const labels = { 'Αθήνα': 'Αθήνα', 'Θεσσαλονίκη': 'Θεσσαλονίκη', 'Πάτρα': 'Πάτρα', 'Ηράκλειο': 'Ηράκλειο', 'Λάρισα': 'Λάρισα' };
    return labels[loc] || loc;
  }
};

// Αρχικοποίηση
DB.init();
